Program written by Travis D.

The purpose of this program is to enable anyone to quickly create a local backup of the Cybergrind Steam leaderboards for the game Ultrakill.
This program will save the first 5001 entries of each leaderboard to the same folder the executable is run from.

Place this program and all the additonal files into an empty folder and run the application.
This wil download approximently 50 mb of data from the steam leaderboards (~10 mb per leaderboard). 
If these files do not appear within 30 seconds simply refresh the folder and they should appear.

